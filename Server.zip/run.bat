@echo off
java Main